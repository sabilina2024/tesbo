const config = {
    owner: ['6285732351432@s.whatsapp.net'], // make format nomormu@s.whatsapp.net
};

module.exports = config;
